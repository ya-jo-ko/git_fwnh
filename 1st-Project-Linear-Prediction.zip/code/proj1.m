clear; close all;

% file = 'speechsample.wav';
file = 'to_elato.wav';

out = lpc_as_toyou(file);

[sig,fs]= audioread(file);
% sound(real(10*out),fs);
% sound(real(10*sig),fs);
% figure; 
% subplot(2,1,1);
% plot(sig(6400:6400+6400)); 
% subplot(2,1,2);
% plot(real(out(6400:6400+6400)));

figure; plot(sig); hold on; plot(real(out));

% audiowrite('speechsample_processed.wav',out,fs);