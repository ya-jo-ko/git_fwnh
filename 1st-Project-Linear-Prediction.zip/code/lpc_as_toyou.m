function [out] = lpc_as_toyou(file)
%
% INPUT:
%   file: input filename of a wav file
% OUTPUT:
%   out: a vector contaning the output signal
%
% Example:
%   
%   out = lpc_as('speechsample.wav');
%   [sig,fs]= wavread('speechsample.wav');
%   sound(out,fs);
%   sound(sig,fs);
%   sound([out [zeros(2000,1);sig(1:length(sig)-2000)]],fs); % create echo
%
%
% Yannis Stylianou
% CSD - CS 578
%
[sig, Fs] = audioread(file);

Horizon = 30;  %30ms - window length
OrderLPC = 24;   %order of LPC
% OrderLPC = 400;   %order of LPC
Buffer = 0;    % initialization
out = zeros(size(sig)); % initialization

Horizon = Horizon*Fs/1000;
Shift = Horizon/2;       % frame size - step size
Win = hanning(Horizon);  % analysis window

Lsig = length(sig);
slice = 1:Horizon;
tosave = 1:Shift;
Nfr = floor((Lsig-Horizon)/Shift)+1;  % number of frames

% analysis frame-by-frame
for l=1:Nfr
    
  sigLPC = Win.*sig(slice);
  en = sum(sigLPC.^2); % get the short - term energy of the input
  
  % LPC analysis
  [r_, lags] = xcorr(sigLPC); % correlation
  r = r_(find(lags==0):end);
  a = my_levinson(r,OrderLPC); % 
  a_lpc = lpc(sigLPC,OrderLPC); a_levinson = levinson(r,OrderLPC); % LPC coef.
%   G(l) = sqrt( r(1) - a*r(2:OrderLPC+1) );  % gain
  G = sqrt( r(1) - a*r(2:OrderLPC+1) );  % gain
  a = [1 -a];
  ex = filter(a,G,sigLPC); % inverse filter
  
  sigLPC_F = fft(sigLPC);
  a_F = freqz(G,a,length(sigLPC_F),'whole');
  sigLPC_F = sigLPC_F(1:round(length(sigLPC_F)/2));
  a_F = a_F(1:round(length(a_F)/2));
%   f = Fs*(1:(Horizon/2))/Horizon;
%   if (l==49 || l==5)
%       figure; semilogy(f,abs(a_F)); hold on; semilogy(f,abs(sigLPC_F));
%       grid on;
%       xlabel('Frequency (Hz)');
%       ylabel('Amplitude (dB)');
%       title('Unvoiced (Order = 100)');
%   end

%   % ---------------------------------------
%   % Vocal Tract
%   roo = roots(a);
%   temp_roo_real = roo(find(imag(roo)==0));
%   temp_roo=roo(find(imag(roo)~=0));
%   [temp,roo3] = sort(abs(temp_roo),'descend');
%   
%   roo_ = temp_roo(roo3(1:2:5));
%   roo_con = temp_roo(roo3(2:2:6));
%   ang_ = angle(roo_);
%   mag_ = abs(roo_);
%   ang_con = angle(roo_con);
%   mag_con = abs(roo_con);
%   
%   % increase 20%
% %   ang_2 = ang_*1.2;
% %   ang_con2 = ang_con*1.2;
%   % decrease 20%
%   ang_2 = ang_*0.8;
%   ang_con2 = ang_con*0.8;
%   
%   roo_ = mag_.*exp(1i*ang_2);
%   roo_con = mag_con.*exp(1i*ang_con2);
%   roo2 = temp_roo;
%   roo2(roo3(1:2:5)) = roo_;
%   roo2(roo3(2:2:6)) = roo_con;
%   roo2 = [roo2; temp_roo_real];
%   new_a = poly(roo2);
%   a = new_a;
%   % ---------------------------------------
  
  % synthesis
  s = filter(G, a, ex);
%   s = filter(G, a, randn(size(ex))); %  WHISPER VOICE
%   robot_ex = ones(size(ex)); robot_ex(1:2:end)=-1;
%   s = filter(G, a, robot_ex); %  ROBOT VOICE
  ens = sum(s.^2);   % get the short-time energy of the output
  g = sqrt(en/ens);  % normalization factor
  s = s*g;           % energy compensation
  s(1:Shift) = s(1:Shift) + Buffer;  % Overlap and add
  out(tosave) = s(1:Shift);          % save the first part of the frame
  Buffer = s(Shift+1:Horizon);       % buffer the rest of the frame
  
  slice = slice+Shift;   % move the frame
  tosave = tosave+Shift;
  
end


