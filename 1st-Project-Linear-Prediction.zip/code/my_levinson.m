function [I_star] = my_levinson(r,p)
% r_ = r./r(1);
r_ = r;

I_0_0 = 0;
E_0 = r_(1);

for i=1:p
    if i-1==0
        k(i) = (r_(i+1)) / E_0;
    else
        k(i) = (r_(i+1) - I(i-1,1:i-1)*r_(i:-1:2)) / E(i-1);
    end
    I(i,i) = k(i);
    if i-1~=0
        for j=1:i-1
            if i-j==0
                I(i,j) = I(i-1,j);
            else
                I(i,j) = I(i-1,j) - k(i)*I(i-1,i-j);
            end
        end
    end
    if i-1==0
        E(i) = (1-k(i)^2)*E_0;
    else
        E(i) = (1-k(i)^2)*E(i-1);
    end
end

I_star = I(p,:);

end
